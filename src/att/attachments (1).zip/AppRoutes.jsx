import React from "react";
import { Route, Routes } from "react-router-dom";
import Appointment from "./component/Appointment";
import Layout from "./component/Layout";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Layout />} />
      <Route path="/Appointment" element={<Appointment />} />
    </Routes>
  );
};

export default AppRoutes;
